//
//  webConstants.swift
//  Condenast-NewsApp
//
//  Created by shree thaanu on 20/01/22.
//

import UIKit
import Foundation
struct GlobalConstant {
    static let likeUrl = "https://cn-news-info-api.herokuapp.com/likes/"
    static let commentUrl = "https://cn-news-info-api.herokuapp.com/comments/"
    static let newsApi = "https://newsapi.org/v2/everything?q=tesla&apiKey=43415fbf109447f092e73b7ad8ddab32"
}
