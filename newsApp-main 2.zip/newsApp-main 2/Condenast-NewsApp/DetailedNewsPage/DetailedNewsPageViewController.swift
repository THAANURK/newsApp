//
//  DetailedNewsPageViewController.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 20/01/22.
//

import UIKit

class DetailedNewsPageViewController: UIViewController {

    @IBOutlet weak var newsDetail: UITextView!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var NewaBanner: UIImageView!

    var newsDetailObject: Article? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        loadaData()
    }
    
    func loadaData(){
        newsTitle.text = newsDetailObject?.title
        NewaBanner.downloaded(from: newsDetailObject!.urlToImage)
        newsDetail.text = newsDetailObject?.description
    }

}
