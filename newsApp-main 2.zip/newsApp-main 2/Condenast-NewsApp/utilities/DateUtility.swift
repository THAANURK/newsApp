//
//  DateUtility.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 21/01/22.
//

import Foundation


func dateConversion(rawDate: String) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
    
    let date = dateFormatter.date(from: rawDate)!
    dateFormatter.dateFormat = "dd-MM-yyyy"
   
    let convertedDate = dateFormatter.string(from: date)
    return convertedDate
    
}
