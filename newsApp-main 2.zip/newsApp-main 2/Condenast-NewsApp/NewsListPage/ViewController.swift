//
//  ViewController.swift
//  Condenast-NewsApp
//
//  Created by shree thaanu on 19/01/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var newsListTable: UITableView!
    private var articleListViewModel: ArticleListViewModel!
    var articleData: [Article] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        let newApiUrl = URL(string: GlobalConstant.newsApi)
        Webservice().getArticles(url: newApiUrl!) { articles in
            if let articles = articles {
                self.articleListViewModel = ArticleListViewModel(articles: articles)
                DispatchQueue.main.async {
                    self.newsListTable.reloadData()
                }
            }
        }
    }
}



extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.articleListViewModel == nil ? 0 : self.articleListViewModel.numberOfSections
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.articleListViewModel.numberOfRowsInSection(section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleTableViewCell", for: indexPath) as! ArticleTableViewCell
        cell.articleTitle.text = articleListViewModel.articles[indexPath.row].title
        cell.articleImage.downloaded(from: articleListViewModel.articles[indexPath.row].urlToImage)
        cell.publishedTime.text = dateConversion(rawDate: articleListViewModel.articles[indexPath.row].publishedAt)
//        if let artlicleAuthor = articleListViewModel.articles[indexPath.row].author {
//            cell.author.text = artlicleAuthor
//        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc : DetailedNewsPageViewController = storyboard.instantiateViewController(withIdentifier: "DetailedNewsPageViewController") as! DetailedNewsPageViewController
        vc.newsDetailObject = articleListViewModel.articles[indexPath.row]
        self.present(vc, animated:true, completion:nil)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}

